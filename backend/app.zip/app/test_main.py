https://fastapi.tiangolo.com/tutorial/testing/


UNIT TESTS


INTEGRATION TESTS