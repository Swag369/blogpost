import logo from './logo.svg';
import './App.css';
import Page from './components/Page';

function App() {
  return (
    <div className="App h-screen">
      <Page />
    </div>
  );
}

export default App;
