import CommentSection from "./comments/CommentSection.js"

export default function Page() {
    return (
        <div className="p-2 h-max">
            Hi
            <CommentSection />      
        </div>
    )
}